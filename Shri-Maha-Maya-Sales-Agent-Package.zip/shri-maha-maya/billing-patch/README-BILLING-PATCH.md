# Billing App → Website Vacancy Sync (patch v1)

Aapka billing app (**HotelBill Pro**, mahamayahotelbillingpallu.netlify.app) **offline PWA** hai —
saara data phone/browser ke localStorage me hota hai, koi server nahi. Isliye humne ulta rasta kiya:
**app khud har change ke baad khali kamron ki ginti hotel backend par bhej deti hai.**

## Ye patch kya karta hai
- `billing-patch/index.html` = aapka POORA billing app + ek chhota sa sync snippet (end me)
- Har **check-in / check-out / room status change / save** ke ~1.5 second baad (aur app khuli ho to har 10 min par)
  app backend ko bhejti hai: `{vacant: {standard, deluxe, family}, source: "billing-app"}`
- Sirf **khali kamron ki ginti** jaati hai — na guest naam, na phone, na bill details
- "Available" status wale rooms gine jaate hain; room type naam se map hota hai (Deluxe→deluxe, Family→family, baaki→standard)
- Website bot (Maya) wahi ginti mehmaan ko batati hai, update-time ke saath; 24 ghante purana data ho to number nahi bolti

## Deploy ke 4 step
1. **Backend (Render/VPS)** env me add karein: `AVAILABILITY_TOKEN=koi-lambi-random-string`
   (jo backend pehle se deploy hai usi me ye env add karein; naya banayein to docs/SETUP-GUIDE.md)
2. Is file (`billing-patch/index.html`) me sabse end me snippet hai — usme 2 line set karein:
   ```js
   url:   "https://aapka-render-backend.onrender.com/api/availability",
   token: "wahi-string-jo-env-me-daali",
   ```
3. **Billing Netlify site** par deploy: Netlify → site → Deploys → is `index.html` ko drag-drop
   (purani site single-file app hai, isliye sirf index.html badalna kaafi hai; baaki icons/manifest wahin rahenge)
4. **Website backend** test: browser me `https://aapka-backend/api/availability` kholein —
   billing app me koi bhi check-in/check-out karein → 2-3 sec me counts badal jane chahiye

## Verify karein
- Billing app me ek room check-in karein → dashboard (`/admin/`) ke "Aaj ki vacancy" card me number turant ghatna chahiye
- Website par Maya se poochhein: *"aaj room vacant hai kya?"* → wahi counts bolegi
- Galat token par backend `401` deta hai (test ho chuka hai)

## Note
- Billing app band ho to sync nahi hota (offline app hai) — khulne par turant + har 10 min sync ho jata hai
- Backend deploy na ho to website bot imaandari se bolti hai: "front desk 24×7 confirm karegi"
- Dashboard par manual card bhi hai — sync ke baad wo card bilkul match dikhega (source: billing-app)
