/* ============================================================
   SHRI MAHA MAYA — VACANCY BRIDGE (Google Apps Script)
   Setup ke 8 click: apps-script/README-APPS-SCRIPT.md
   Billing app chit bhejti hai → sheet me save → Maya padhti hai
   ============================================================ */
const TOKEN = "smm-666ed7300f4b49035fc2aecf";

function sheet_() {
  const ps = PropertiesService.getScriptProperties();
  let ss = null;
  const id = ps.getProperty("SSID");
  if (id) { try { ss = SpreadsheetApp.openById(id); } catch (e) { ss = null; } }
  if (!ss) {
    ss = SpreadsheetApp.create("Maya-Vacancy-Shri-Maha-Maya");
    ps.setProperty("SSID", ss.getId());
  }
  let sh = ss.getSheetByName("Vacancy");
  if (!sh) {
    sh = ss.insertSheet("Vacancy");
    sh.appendRow(["standard", "deluxe", "family", "updatedAt", "source"]);
    sh.appendRow([0, 0, 0, "", ""]);
  }
  return sh;
}
const json_ = (obj) => ContentService.createTextOutput(JSON.stringify(obj))
  .setMimeType(ContentService.MimeType.JSON);
const num_ = (v) => Math.max(0, Math.min(10, Number(v) || 0));

function doGet(e) {
  const p = e.parameter || {};
  /* manual update link (phone bookmark): /exec?action=set&token=...&s=2&d=1&f=3 */
  if (p.action === "set") {
    if ((p.token || "") !== TOKEN) return json_({ ok: false, error: "bad-token" });
    sheet_().getRange(2, 1, 1, 5).setValues([[num_(p.s), num_(p.d), num_(p.f), new Date().toISOString(), "manual-link"]]);
    return json_({ ok: true });
  }
  const r = sheet_().getRange(2, 1, 1, 5).getValues()[0];
  const av = (r[3] || "") ? { updatedAt: String(r[3]), source: String(r[4] || ""), vacant: { standard: Number(r[0]) || 0, deluxe: Number(r[1]) || 0, family: Number(r[2]) || 0 } } : null;
  return json_({ ok: true, availability: av });
}

function doPost(e) {
  let b = {};
  try { b = JSON.parse(e.postData.contents); } catch (err) { return json_({ ok: false, error: "bad-json" }); }
  if ((b.token || "") !== TOKEN) return json_({ ok: false, error: "bad-token" });
  const v = b.vacant || {};
  sheet_().getRange(2, 1, 1, 5).setValues([[num_(v.standard), num_(v.deluxe), num_(v.family), new Date().toISOString(), String(b.source || "billing-app").slice(0, 40)]]);
  return json_({ ok: true });
}
