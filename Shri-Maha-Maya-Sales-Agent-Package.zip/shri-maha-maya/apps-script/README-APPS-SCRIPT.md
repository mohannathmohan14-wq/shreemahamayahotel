# Google Apps Script Setup — 8 click ka kaam 📋

Ye bridge billing app ↔ website jodta hai, **bina kisi server ke** (aapka Gmail account hi kaafi hai).
Chabi (token) file me pehle se bhari hai — aapko sirf copy-paste aur deploy karna hai.

## Step 1 — Project banaiye (2 click)
1. Browser me kholein: **script.google.com** (shreemahamayahotel@gmail.com se login)
2. **"+ New project"** dabaiye

## Step 2 — Code paste kijiye (2 click)
3. Beech me jo code likha hai wo **poora select karke delete** kijiye (Ctrl+A → Delete)
4. Is package ki file **`apps-script/Code.gs`** kholiye, poora content copy karke yahan paste kijiye → 💾 (Ctrl+S)

## Step 3 — Deploy kijiye (3 click)
5. Upar right **"Deploy"** → **"New deployment"**
6. ⚙️ (gear) icon → type me **"Web app"** chuniye
   - **Execute as:** Me (apna email)
   - **Who has access:** **Anyone** ← zaroori, warna Maya padh nahi payegi
7. **"Deploy"** dabaiye → Google permission maangega:
   - "Advanced" → "**Go to …(unsafe)**" link → Allow   *(ye safe hai — script sirf aapki ek sheet banata hai, kuch aur nahi)*

## Step 4 — URL bhejiye (1 click)
8. Jo **"Web app URL"** dikhe (ends with `/exec`) — **copy karke mujhe chat me paste kar dijiye**

## Bas! Uske baad main karunga
- URL billing-app patch me + website config me daal dunga
- Aapko 2 ready files dungi: billing site ke liye index.html, website ke liye ZIP — dono drag-drop
- Phir saath me test karenge: billing me check-in → Maya se poochhein "room vacant hai?" ✅

## Manual update ka shortcut (optional)
Sheet apne aap ban jayegi: Google Drive me "**Maya-Vacancy-Shri-Maha-Maya**".
Usme row 2 me 3 number khud badal sakte hain (Standard/Deluxe/Family khali) — time apne aap update hoga.
Ya phone me ye bookmark rakhiye (numbers badal kar):
```
https://SCRIPT-ID/exec?action=set&token=TOKEN_YAHAN&s=2&d=1&f=3
```
(token = Code.gs me pehli line wahi hai)

## Privacy
- Sheet me sirf 3 number + time + source jaata hai — guest ka naam/phone/bill kabhi nahi
- Padhai (GET) public hai kyunki sirf ginti hai; likhai (POST/set) token ke bina reject hoti hai
